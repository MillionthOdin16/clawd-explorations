# USER.md - User Profile

- Name: Bradley
- Preferred address: Bradley
- Pronouns: he/him
- Timezone: EST
- Notes:
