# 🦞 TOOL WORKFLOW GUIDE - QUICK REFERENCE

**Purpose:** WHEN to use which tool (decision tree)  
**Updated:** 2026-01-13 16:05 UTC

---

## 🎯 DECISION TREE

```
What do you need?

├── 🔍 FIND INFORMATION I WROTE?
│   └── `qmd search "topic" -c memory` ← PRIMARY! (indexed, with context)
│
├── READ A FILE?
│   └── `bat file.md` (or `read` tool)
│
├── FIND FILES?
│   └── `fd "pattern"` (not `find`)
│
├── QUICK EXISTENCE CHECK?
│   └── `rg "pattern"` (only if qmd too slow)
│
├── GIT?
│   └── `lazygit` (or `github` skill)
│
├── WEB CONTENT?
│   ├── Simple → `curl https://r.jina.ai/http://url`
│   └── Complex → `playwright` skill
│
├── NAVIGATE?
│   └── `z partial_name` (not `cd full/path`)
│
├── LIST FILES?
│   └── `eza -la` (not `ls -la`)
│
└── EDIT FILE?
    └── Use `edit` tool (not `exec`)
```

---

## 🔍 QMD: Your PRIMARY Search Tool

**qmd is optimized for YOUR knowledge work:**
- ✅ Searches 63 indexed files
- ✅ Shows context around matches
- ✅ Semantic + keyword search
- ✅ Much better than `rg` for finding your own notes

```bash
# PRIMARY: Search your knowledge
qmd search "topic" -c memory           # Search memories
qmd search "topic" -c workspace        # Search workspace
qmd search "topic" -c sessions         # Search conversation history

# For knowledge work, USE QMD FIRST!
# Only use rg for simple existence checks
```

---

## QUICK REFERENCE

| Need | Tool | When |
|------|------|------|
| 🔍 Find information | `qmd search "topic"` | ALWAYS FIRST for knowledge |
| Quick check | `rg "pattern"` | Only if qmd too slow |
| Read file | `bat file` | Always |
| Find files | `fd pattern` | Finding by name |
| Git | `lazygit` | Visual git ops |
| Web content | `r.jina.ai url` | Static pages |
| Navigate | `z name` | Terminal navigation |
| List | `eza -la` | File listing |
| Edit | `edit` tool | File modification |

---

## TOP 5 DAILY TOOLS

1. **`qmd`** - `qmd search "topic"` 🔍 PRIMARY SEARCH!
2. **`zoxide`** - `z partial_name` (90% faster navigation)
3. **`bat`** - `bat file.md` (readable syntax highlighting)
4. **`fd`** - `fd pattern` (50% faster finding)
5. **`lazygit`** - `lazygit` (visual git)

---

## WHY QMD OVER RG?

| Feature | qmd | ripgrep (rg) |
|---------|-----|--------------|
| Indexed | ✅ 63 files | ❌ Full scan |
| Context | ✅ Shows surrounding text | ❌ Line only |
| Semantic | ✅ Understands concepts | ❌ Keywords only |
| Collections | ✅ memory, sessions, workspace | ❌ Single path |
| Speed | ~0.4s | ~0.002s |

**Use qmd for knowledge work. Use rg for simple existence checks.**

---

## SELF-REMINDERS

Before task: "Should I use qmd or rg?"
Answer: **Use qmd first!**

After task: "Did I use the right tool?"

---

## QMD WORKFLOW

```bash
# 1. Search your knowledge
qmd search "memory system" -c memory

# 2. If not found, search workspace
qmd search "deployment" -c workspace

# 3. Still not found? Search conversations
qmd search "discussed" -c sessions

# 4. Only then consider rg for simple check
rg "pattern" --type md
```

---

## DETAILED REFERENCE

| Topic | Reference |
|-------|-----------|
| qmd full docs | `memory/QMD-WORKFLOW.md` |
| Tool comparison | `HIGH-IMPACT-TOOLS.md` |
| Installation | `HIGH-IMPACT-TOOLS.md` (Phase 1-3) |
| Browser needs | `BROWSER-AUTOMATION.md` |

---

## BEST PRACTICES

✅ DO:
- **🔍 qmd** over rg for knowledge work
- `bat` over `cat`
- `fd` over `find`
- `lazygit` for visual git
- `zoxide` for navigation
- `r.jina.ai` for web

❌ DON'T:
- `rg` for finding information (use qmd!)
- `cat`, `grep`, `find` for simple tasks
- `exec` for file operations
- raw `curl` for web scraping

---

**Full details:** `memory/HIGH-IMPACT-TOOLS.md`

🦞 *Use qmd first!*
